import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.datatransfer.Clipboard; 
import java.awt.datatransfer.Transferable; 
import java.awt.datatransfer.DataFlavor; 
import java.awt.datatransfer.UnsupportedFlavorException; 
import java.awt.Toolkit; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Browser_of_sorts extends PApplet {

String[] html;
String Page[];
String title;
int place = 0;
int place2 = 0;
int j;
int state = 0;
String result="";
String PagePre;
float scroll = 50;
PImage image;
boolean imageShow;
int x;
int counter;

public void setup() {
  
  textSize(15);
  surface.setTitle("Title - Metype's HTML Viewer");
  Page = loadStrings("https://www.google.com");
  PagePre = Page[0];
  html = loadStrings("https://www.google.com");
  surface.setResizable(true);
}

public void draw() {
  if (Page[0] != PagePre) {
          println(result);
        if (result == "") {
      html = loadStrings("https://www.google.com");
    }
          println(result);
    html = loadStrings(result);
    if (html == null) {
      println(result);
      html = loadStrings("https://" + result);
    }
    if (html == null) {
      println(result);
      html = loadStrings("https://" + result + ".com");
    }
        if (html == null) {
          println(result);
      html = loadStrings(result + ".com");
    }
            if (html == null) {
      html = loadStrings(result + ".org");
    }
            if (html == null) {
      html = loadStrings("https://" + result + ".org");
    }
            if (html == null) {
      html = loadStrings(result + ".net");
    }
            if (html == null) {
      html = loadStrings("https://" + result + ".net");
    }
        if (html == null) {
      html = loadStrings("https://www.google.com/search?q=" + result);
    }
        if (html == null) {
      html = loadStrings("https://www.google.com");
    }
    result = "";
    scroll = 50;
  }
  if (x > 0) {
   x = 0; 
  }
  PagePre = Page[0];
  background(220);
  for (int i = 1; i < html.length; i++) {
    fill(0);
    if (!imageShow) {
      text(html[i].length(),50 + x, scroll + i * 20);
            text(i,5 + x, scroll + i * 20);
      line(0,scroll + i * 20 + 5,width,scroll + i * 20 + 5);
      line(95 + x,0,95 + x,height);
      line(45 + x,0,45 + x,height);
      text(html[i], 120 +x, scroll + i * 20); 
    } else {
      imageMode(CENTER);
      image (image, width / 2, height / 2 + scroll);
    }
    place = html[i].indexOf("<");
    place2 = html[i].indexOf("</");
    if (place < 0 || place2 < 0) {
      place = 0;
      place2 = 0;
    }
    if (html[i].length() > place + 6) {
      title = html[i].substring(abs(place), place + 7);
    }
    if (title.equals("<title>")) {
      println(place);
      println(place2);
      println(i);
      if (place2 > place) {
            title = html[i].substring(place + 7, place2);
            surface.setTitle(title + " - Metype's HTML Viewer");
      }
    } 
    textBox();
     if (counter > 130) {
   if (counter > 300) {
    counter = 0; 
   } else {
     fill(0);
     stroke(0);
    line(83 + textWidth(result), 22, 83 +textWidth(result), 8); 
    fill(0);
    stroke(0);
    counter++;
   }
  } else {
   counter++; 
  }
  }
}

public void changeAppIcon(PImage img) {
  final PGraphics pg = createGraphics(16, 16, JAVA2D);

  pg.beginDraw();
  pg.image(img, 0, 0, 16, 16);
  pg.endDraw();
  frame.setIconImage(pg.image);
}


public void mouseWheel(MouseEvent event) {
  scroll -= event.getCount() * 20;
  if (scroll > 50) {
    scroll = 50;
  }
}






public String getTextFromClipboard (){
  String text = (String) getFromClipboard(DataFlavor.stringFlavor);
  return text;
}



public Object getFromClipboard (DataFlavor flavor) {

  Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard(); 
  Transferable contents = clipboard.getContents(null);
  Object object = null;

  if (contents != null && contents.isDataFlavorSupported(flavor))
  {
    try
    {
      object = contents.getTransferData(flavor);
   
    }

    catch (UnsupportedFlavorException e1) // Unlikely but we must catch it
    {
      //~  e1.printStackTrace();
    }

    catch (java.io.IOException e2)
    {
      //~  e2.printStackTrace();
    }
  }

  return object;
} 

public void textBox() { 
  fill(100);
  rectMode(CORNER);
  rect(-1, -1, width + 20, 30);
    fill(255);
  rectMode(CORNER);
  rect(15, 5, width - 30, 20);




  switch (state) {
  case 0:
    fill(0); 
    text ("Search : "+ result, 20, 20); 
    break;

  case 1:
    Page[0] = result;
    state = 0;
  }
  fill(255);
}

public void keyPressed() {
  if (keyPressed) {
    if (key==ENTER||key==RETURN) {

      state++;
    } else if (key==BACKSPACE) {
      if (result.length() > 0) {
        result = result.substring(0, result.length()-1);
      }
    } else if (keyCode==SHIFT) {
    } else if (keyCode==CONTROL) {
    } else if (keyCode == 86) {
      result = result + getTextFromClipboard();
    } else if (keyCode == UP) {
      scroll += 10;
      if (scroll > 10) {
       scroll = 10; 
      }
    } else if (keyCode == DOWN) {
      scroll -= 10;
    } else if (keyCode == LEFT) {
      x += 10;
    } else if (keyCode == RIGHT) {
      x -= 10;
    } else {
      result = result + key;
    }
  }
}
  public void settings() {  size(1280, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Browser_of_sorts" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
